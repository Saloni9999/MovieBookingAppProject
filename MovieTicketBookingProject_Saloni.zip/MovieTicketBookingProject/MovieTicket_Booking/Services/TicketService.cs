﻿using MongoDB.Driver;
using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public class TicketService : ITicketService
    {
        private readonly IMongoCollection<Ticket> _ticket;
        public TicketService(IMoviesDatabaseSettings moviesDatabaseSettings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(moviesDatabaseSettings.DatabaseName);
            _ticket = database.GetCollection<Ticket>("Ticket_Collection");
        }

        public Ticket Create(Ticket ticket)
        {
            ticket.Id = MongoDB.Bson.ObjectId.GenerateNewId().ToString();
            _ticket.InsertOne(ticket);
            return ticket;
        }

        public List<Ticket> GetTickets()
        {
            return _ticket.Find(a => true).ToList();
        }

        public List<Ticket> GetTicketsByMovieName(string movieName)
        {
            return _ticket.Find(a => a.MovieName == movieName).ToList();
        }


        public void Delete(Ticket ticket)
        {
            //_ticket.FindOneAndDelete(ticket)
        }
    }
}
