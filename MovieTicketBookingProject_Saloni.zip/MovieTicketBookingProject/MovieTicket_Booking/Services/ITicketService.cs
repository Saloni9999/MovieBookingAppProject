﻿using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public interface ITicketService
    {
        List<Ticket> GetTickets();
        Ticket Create(Ticket ticket);
        List<Ticket> GetTicketsByMovieName(string movieName);
    }
}
