﻿using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public interface ICustomerService
    {
        List<Customer> GetCustomers();
        Customer Create(Customer customer);
    }
}
