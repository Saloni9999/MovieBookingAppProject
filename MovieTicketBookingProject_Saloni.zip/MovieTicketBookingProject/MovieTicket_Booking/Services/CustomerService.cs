﻿using MongoDB.Driver;
using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public class CustomerService : ICustomerService
    {

        private readonly IMongoCollection<Customer> _cust;
        public CustomerService(IMoviesDatabaseSettings moviesDatabaseSettings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(moviesDatabaseSettings.DatabaseName);
            _cust = database.GetCollection<Customer>("Customer_Collection");
            _cust.Indexes.CreateOne(
                new CreateIndexModel<Customer>(
                    Builders<Customer>.IndexKeys.Descending(m=>m.EmailId),
                new CreateIndexOptions { Unique= true}));
        }
        public Customer Create(Customer customer)
        {
            _cust.InsertOne(customer);
            return customer;
        }

        public List<Customer> GetCustomers()
        {
            return _cust.Find(a => true).ToList();
        }

    }
}
