﻿using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public interface IMoviesService
    {
        List<Movie> Get();
        Movie Create(Movie movie);
        Movie GetByName(string name);
        Movie GetByNameAndThreaterName(string movieName, string threaterName);
        bool DeleteMovie(Movie movie);

    }
}
