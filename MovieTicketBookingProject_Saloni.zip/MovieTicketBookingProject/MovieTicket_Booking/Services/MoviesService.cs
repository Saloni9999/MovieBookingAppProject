﻿using MongoDB.Driver;
using MovieTicket_Booking.Models;

namespace MovieTicket_Booking.Services
{
    public class MoviesService : IMoviesService
    {
        private readonly IMongoCollection<Movie> _movies;
        public MoviesService(IMoviesDatabaseSettings moviesDatabaseSettings, IMongoClient mongoClient) {
            var database= mongoClient.GetDatabase(moviesDatabaseSettings.DatabaseName);
            //_movies= database.GetCollection<Movie>(moviesDatabaseSettings.MoviesCollectionName);
            _movies = database.GetCollection<Movie>("Movie_Collection");

        }
        public Movie Create(Movie movie)
        {
            _movies.InsertOne(movie);
            return movie;
        }

        public List<Movie> Get()
        {
            return _movies.Find(a => true).ToList();
        }
        public Movie GetByName(string name)
        {
            return _movies.Find(a => a.Key.MovieName== name).FirstOrDefault();
        }

        public Movie GetByNameAndThreaterName(string movieName, string threaterName)
        {
            return _movies.Find(a => a.Key.MovieName == movieName && a.Key.ThreaterName == threaterName).FirstOrDefault();
        }

        public bool DeleteMovie(Movie movie)
        {
            var deleteFilter = Builders<Movie>.Filter.Where(a => a.Key.MovieName == movie.Key.MovieName);
            _movies.DeleteMany(deleteFilter);
            return true;
        }
    }
}
