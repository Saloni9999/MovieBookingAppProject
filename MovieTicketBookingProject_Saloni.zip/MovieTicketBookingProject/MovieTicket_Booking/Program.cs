using Confluent.Kafka;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using MongoDB.Driver;
using MovieTicket_Booking.KafkaServices;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using Serilog;
using Serilog.Sinks.Kafka;
using Swashbuckle.AspNetCore.Filters;

var builder = WebApplication.CreateBuilder(args);

//var config = new ProducerConfig
//{
//    BootstrapServers = "localhost:9092",
//};
//using (var producer = new ProducerBuilder<Null, string>(config).Build())
//{
//    builder.Logging.AddProvider(new KafkaLoggerProvider(producer, "movieTopic"));
//}
//builder.Services.AddHostedService<KafkaConsumer>();

//Kafka
builder.Services.AddSingleton<IKafkaProducer,KafkaProducer>();
builder.Services.AddSingleton<KafkaConsumer>();


//Log
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    //.WriteTo.File("Log/log.txt")
    .WriteTo.Kafka("localhost:9092",topic: "movieTopic")
    .CreateLogger();


// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle


//CORS
builder.Services.AddCors(o =>
{
    o.AddPolicy("corspolicy", builder =>
    {
        builder.AllowAnyOrigin()
        .AllowAnyMethod()
        .AllowAnyHeader();
    });
});


//Swgger Authorization
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.AddSecurityDefinition("Bearer", new Microsoft.OpenApi.Models.OpenApiSecurityScheme
    {
        Description = "JWT Authentication header",
        Name = "Authorization",
        In = Microsoft.OpenApi.Models.ParameterLocation.Header,
        Type = Microsoft.OpenApi.Models.SecuritySchemeType.ApiKey,
        BearerFormat = "JWT",
        Scheme = "bearer"
    });
    o.AddSecurityRequirement(new Microsoft.OpenApi.Models.OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    }
    );
});

//Mongo Db
builder.Services.AddSingleton<IMongoClient>(options =>
    new MongoClient (builder.Configuration.GetValue<string>("MoviesDatabaseSettings:ConnectionString")));

builder.Services.Configure<MoviesDatabaseSettings>(
    builder.Configuration.GetSection(nameof(MoviesDatabaseSettings)));

builder.Services.AddSingleton<IMoviesDatabaseSettings>(sp =>
    sp.GetRequiredService<IOptions<MoviesDatabaseSettings>>().Value);

builder.Services.AddScoped<IMoviesService, MoviesService>();
builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<ITicketService, TicketService>();

//Authentication
builder.Services.AddAuthentication(o =>
{
    o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;  
})
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new Microsoft.IdentityModel.Tokens.TokenValidationParameters
        {
            ValidateIssuer = false,
            //ValidIssuer = "https://localhost:44302/swagger/index.html",
            ValidateAudience = false,
            //ValidAudience = "https://localhost:44328/swagger/index.html",
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("Security_key_random_drh4s5hcar8jh")),
            ValidateLifetime = true,
        };
    })
;

builder.Host.UseSerilog();



var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

//var consumer = app.Services.GetRequiredService<KafkaConsumer>();
//consumer.Start();

//Task.Run(async () =>
//{
//    //using var scope = app.Services.CreateScope();
//    var consumer = app.Services.GetRequiredService<KafkaConsumer>();
//    await consumer.StartAsync(app.Ca);
//});

app.Run();
