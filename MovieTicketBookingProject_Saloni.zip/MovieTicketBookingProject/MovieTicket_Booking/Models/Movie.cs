﻿



using MongoDB.Bson.Serialization.Attributes;

namespace MovieTicket_Booking.Models
{
    public class Movie
    {
        [BsonId]
        public MovieThreaterKey Key { get; set; }
        public int NoOfTicketsAlloted { get; set; }       
    }
   
    public class MovieThreaterKey
    {
        public string MovieName { get; set; }
        public string ThreaterName { get; set; }
    }
}
