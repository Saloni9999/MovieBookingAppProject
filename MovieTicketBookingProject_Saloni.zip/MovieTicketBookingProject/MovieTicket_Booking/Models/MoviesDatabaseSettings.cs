﻿namespace MovieTicket_Booking.Models
{
    public class MoviesDatabaseSettings: IMoviesDatabaseSettings
    {
        public string MoviesCollectionName { get; set; } = String.Empty;
        public string ConnectionString { get; set; } = String.Empty;
        public string DatabaseName { get; set; }= String.Empty;
    }
}
