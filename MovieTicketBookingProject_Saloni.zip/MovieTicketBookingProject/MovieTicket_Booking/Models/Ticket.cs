﻿using MongoDB.Bson.Serialization.Attributes;

namespace MovieTicket_Booking.Models
{
    public class Ticket
    {
        [BsonId]
        public string Id { get; set; }
        public string MovieName { get; set; }
        public string ThreaterName { get; set; }
        public int NoOfTickets { get; set;}
        public string SeatNumber { get; set; }
    }

    
}
