﻿using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace MovieTicket_Booking.Models
{
    public class Customer
    {
        [BsonId]
        [Required]
        //[BsonIndex(IsUnique = true)]
        public string LoginId { get; set; }
        [Required]
        public string FirstName { get; set; }
        [Required]
        public string LastNmae { get; set; }
        [Required]
        [EmailAddress]
        
        public string EmailId { get; set; }
        [Required]
        [PasswordPropertyText]
        public string Password { get; set; }
        [Required]
        [Phone]
        public string ContactNumber { get; set; }

    }
}
