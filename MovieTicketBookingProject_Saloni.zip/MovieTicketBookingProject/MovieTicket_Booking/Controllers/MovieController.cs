﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;

namespace MovieTicket_Booking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly IMoviesService _moviesService;
        private readonly ILogger<MovieController> _logger;  

        public MovieController(IMoviesService moviesService, ILogger<MovieController> logger)
        {
            _moviesService = moviesService;
            _logger = logger;
        }

        [HttpGet("GetAllMovies")]
        [Authorize(Roles = "User")]
        public ActionResult<List<Movie>> GetAllMovies()
        {
            _logger.LogInformation("Getting all movies from database");
            return _moviesService.Get();
        }
        
        [HttpGet("GetMovieByName")]
        [Authorize(Roles = "User")]
        public ActionResult<Movie> GetMovieByName(string name)
        {
            _logger.LogInformation($"Movie {name}");
            return _moviesService.GetByName(name);
        }

        
    }
}
