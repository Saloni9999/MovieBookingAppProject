﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicket_Booking.KafkaServices;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using Newtonsoft.Json;

namespace MovieTicket_Booking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class TicketController : ControllerBase
    {
        private readonly ITicketService _ticketService;
        private readonly IMoviesService _movieService;
        private readonly ILogger<TicketController> _logger;
        private readonly IKafkaProducer _producer;
        
        public TicketController(ITicketService ticketService, IMoviesService moviesService, ILogger<TicketController> logger, IKafkaProducer producer)
        {
            _ticketService = ticketService;
            _movieService = moviesService;
            _logger = logger;
            _producer = producer;
        }


        [HttpPost("BookTicket")]
        [Authorize(Roles = "User")]
        public ActionResult<Ticket> BookTicket(Ticket ticket)
        {
            _logger.LogInformation("Booking a ticket");
            var movieThreater = new Movie();
            movieThreater = _movieService.GetByNameAndThreaterName(ticket.MovieName, ticket.ThreaterName);
            if(movieThreater ==null || movieThreater.NoOfTicketsAlloted == 0)
            {
                _logger.LogInformation("Tickets not available for user searched movie");
                return NotFound("Tickets not available in this threater");
            }
            _ticketService.Create(ticket);
            return ticket;
        }



        //public TicketController(ITicketService ticketService, KafkaMessageService messageService, KafkaAdminService adminService, ILogger<TicketController>  logger, KafkaProducer producer)
        //{
        //    _ticketService = ticketService;
        //    _messageService = messageService;
        //    _adminService = adminService;
        //    _logger = logger;
        //    _producer = producer;
        //}

        //[HttpPost]
        //[Authorize(Roles = "User")]
        //public async Task<ActionResult<Ticket>> BookTicket2(Ticket ticket)
        //{
        //    await _messageService.SendMessageAsync("movieTopic", JsonConvert.SerializeObject(ticket));
        //    return ticket;
        //}

        //[HttpPost("produce")]
        //public IActionResult Producemessage([FromBody] string message)
        //{
        //    _producer.Produce(message, "movieTopic");
        //    return Ok();
        //}

        //bin\windows\zookeeper-server-start.bat config\zookeeper.properties
        //    bin\windows\kafka-server-start.bat config\server.properties
        //bin\windows\kafka-topics.bat --create --topic user-topic --bootstrap-server localhost:9092
        //kafka-topics.bat --create --bootstrap-server localhost:9092 --replication-factor 1 --partitions 3 --topic movieTopic
        //bin\windows\kafka-console-producer.bat --broker-list localhost:9092 --topic movieTopic
        //bin\windows\kafka-console-consumer.bat --bootstrap-server localhost:9092 --topic movieTopic --from-beginning

    }
}
