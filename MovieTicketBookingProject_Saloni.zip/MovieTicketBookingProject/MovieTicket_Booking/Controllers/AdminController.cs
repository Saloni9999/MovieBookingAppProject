﻿using Confluent.Kafka;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MovieTicket_Booking.KafkaServices;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;

namespace MovieTicket_Booking.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Admin")]
    public class AdminController : ControllerBase
    {
        private readonly ITicketService _ticketService;
        private readonly IMoviesService _moviesService;
        private readonly ILogger<AdminController> _logger;
        private readonly IKafkaProducer _producer;

        public AdminController(ITicketService ticketService, IMoviesService moviesService, ILogger<AdminController> logger, IKafkaProducer producer)
        {
            _ticketService = ticketService;
            _moviesService = moviesService;
            _logger = logger;
            _producer = producer;
        }

        [HttpGet("GetBookedTickets")]
        [Authorize(Roles = "Admin")]
        public ActionResult<List<Ticket>> BookedTickets(string movieName)
        {
            List<Ticket> tickets= new List<Ticket>();
            _logger.LogInformation("Geting Booked Tickets");
            tickets = _ticketService.GetTicketsByMovieName(movieName);
            return tickets;
        }

        [HttpPost("GetTicketsRemaining")]
        [Authorize(Roles = "Admin")]
        public ActionResult<int> GetTicketsRemaining(string movieName ,string threaterName)
        {
            Movie movie = new Movie();
            _logger.LogInformation($"GetTicketsRemaining {movieName}");
            movie = _moviesService.GetByNameAndThreaterName(movieName, threaterName);
            int ticketsRemaining = 0, bookedTickets=0;
            if (movie == null)
            {
                return 0;
            }
            List<Ticket> tickets = _ticketService.GetTickets();
            
            foreach(var tik in tickets)
            {
                if(tik.MovieName == movie.Key.MovieName && tik.ThreaterName == movie.Key.ThreaterName)
                {
                    bookedTickets += tik.NoOfTickets;
                }
            }
            ticketsRemaining = movie.NoOfTicketsAlloted- bookedTickets;
            if(ticketsRemaining > 0) 
                _producer.Produce("BookAsap", "movieTopic");
            return ticketsRemaining;
        }

        [HttpPost("AddMovie")]
        [Authorize(Roles = "Admin")]
        public ActionResult<Movie> PostMovie(Movie movie)
        {
            _logger.LogInformation("Adding a new movie to Database");
            try
            {
                _moviesService.Create(movie);
                return movie;
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("DeleteMovie")]
        public ActionResult<bool> DeleteMovie(Movie movie)
        {
            _logger.LogInformation("Deleting a movie");
            return _moviesService.DeleteMovie(movie);
        }
    }
}
