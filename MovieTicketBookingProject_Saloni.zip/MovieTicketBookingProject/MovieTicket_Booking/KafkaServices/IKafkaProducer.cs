﻿namespace MovieTicket_Booking.KafkaServices
{
    public interface IKafkaProducer
    {
        void Produce(string message, string topic);
    }
}
