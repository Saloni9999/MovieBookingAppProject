﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaAdminService
    {
        private readonly IConsumer<Null, string> _consumer;
        public KafkaAdminService (IConsumer<Null, string> consumer)
        {
            _consumer = consumer;
        }

        public async Task<string> ReadMessageAsync(string topic)
        {
            _consumer.Subscribe(topic);
            var consumeResult = _consumer.Consume();
            return consumeResult.Message.Value;
        }
    }
}
