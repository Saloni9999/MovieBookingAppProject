﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaLoggerProvider : ILoggerProvider
    {
        private readonly IProducer<Null, string> _producer;
        private readonly string _topic;
        public KafkaLoggerProvider(IProducer<Null, string> producer, string topic)
        {
            _producer = producer;
            _topic = topic;
        }
        public ILogger CreateLogger(string categoryName)
        {
            return new KafkaLogger(_producer, _topic);
        }

        public void Dispose()
        {
            _producer.Dispose();
        }
    }
}
