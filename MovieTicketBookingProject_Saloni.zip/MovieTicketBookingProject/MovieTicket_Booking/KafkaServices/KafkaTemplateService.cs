﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaTemplateService
    {
        private readonly IProducer<Null, string> _producer;
        private readonly IConsumer<Null, string> _consumer;
        public KafkaTemplateService(IProducer<Null, string> producer, IConsumer<Null, string> consumer)
        {
            _producer = producer;
            _consumer = consumer;
        }

        public async Task SendMessageAsync(string topic, string message)
        {
            await _producer.ProduceAsync(topic, new Message<Null, string> { Value= message });
        }

        public async Task<string> ReceiveMessageAsync(string topic)
        {
            _consumer.Subscribe(topic);
            var consumeResult = _consumer.Consume();
            return consumeResult.Message.Value;
        }
    }
}
