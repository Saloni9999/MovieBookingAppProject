﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaMessageService
    {
        private readonly IProducer<Null, string> _producer;
        public KafkaMessageService(IProducer<Null, string> producer)
        {
            _producer = producer;
        }

        public async Task SendMessageAsync(string topic, string message)
        {
            await _producer.ProduceAsync(topic, new Message<Null, string> { Value= message });
        }


    }
}
