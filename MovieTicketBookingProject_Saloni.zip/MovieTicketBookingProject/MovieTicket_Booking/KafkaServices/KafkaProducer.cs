﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaProducer : IKafkaProducer
    {
        private readonly ILogger<KafkaProducer> _logger;
        private readonly ProducerConfig _config;
        public KafkaProducer(ILogger<KafkaProducer> logger)
        {
            _logger = logger;
            _config = new ProducerConfig
            {
                BootstrapServers = "localhost:9092"
            };
        }

        public void Produce(string message, string topic)
        {
            using var producer = new ProducerBuilder<Null, string>(_config).Build();
            try
            {
                var messageReport = producer.ProduceAsync(topic, new Message<Null, string> { Value = message }).GetAwaiter().GetResult();
                _logger.LogInformation($"Producer message to : {messageReport.TopicPartitionOffset}");

            }
            catch (Exception ex)
            {
                //_logger.LogError("Some erroe");
            }
        }

    }

    
}
