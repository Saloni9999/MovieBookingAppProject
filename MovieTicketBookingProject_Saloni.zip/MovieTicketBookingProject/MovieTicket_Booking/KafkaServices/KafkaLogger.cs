﻿using Confluent.Kafka;

namespace MovieTicket_Booking.KafkaServices
{
    public class KafkaLogger : ILogger
    {
        private readonly IProducer<Null, string> _producer;
        private readonly string _topic;
        public KafkaLogger(IProducer<Null, string> producer, string topic)
        {
            _producer = producer;
            _topic = topic;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            var message = formatter(state, exception);
            _producer.ProduceAsync(_topic, new Message<Null, string> { Value= message });
        }
    }
}
