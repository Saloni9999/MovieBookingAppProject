﻿using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace AuthenticationService.Model
{
    public class LoginCred
    {
        [BsonId]
        [Required]
        //[BsonIndex(IsUnique = true)]
        public string LoginId { get; set; }
        
        [Required]
        [EmailAddress]
        public string EmailId { get; set; }
        public string UserRole { get; set; }

        
        public byte[] PasswordHash { get; set; } = default!;
        public byte[] PasswordSalt { get; set; } = default!;

    }
}
