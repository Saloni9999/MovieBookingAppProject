using Microsoft.Extensions.Options;
using MongoDB.Driver;
using AuthenticationService.Model;
using AuthenticationService.Services;
using AuthenticationService.Security;
using Serilog;
using AuthenticationService.KafkaServices;
using Serilog.Sinks.Kafka;

var builder = WebApplication.CreateBuilder(args);

//Kafka
builder.Services.AddSingleton<IKafkaProducer, KafkaProducer>();
builder.Services.AddSingleton<KafkaConsumer>();


//Log
Log.Logger = new LoggerConfiguration()
    .MinimumLevel.Information()
    //.WriteTo.File("Log/log.txt")
    .WriteTo.Kafka("localhost:9092", topic: "movieTopic")
    .CreateLogger();



// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddSingleton<IMongoClient>(options =>
    new MongoClient(builder.Configuration.GetValue<string>("MoviesDatabaseSettings:ConnectionString")));

builder.Services.Configure<MoviesDatabaseSettings>(
    builder.Configuration.GetSection(nameof(MoviesDatabaseSettings)));

builder.Services.AddSingleton<IMoviesDatabaseSettings>(sp =>
    sp.GetRequiredService<IOptions<MoviesDatabaseSettings>>().Value);

builder.Services.AddScoped<ICustomerService, CustomerService>();
builder.Services.AddScoped<IAuthenticationIdentity, AuthenticationIdentity>();

builder.Host.UseSerilog();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
