﻿using AuthenticationService.Model;

namespace AuthenticationService.Services
{
    public interface ICustomerService
    {
        List<Customer> GetCustomers();
        Customer Create(Customer customer);
        Customer GetById(string loginId);
        LoginCred GetLoginCred(string loginId);
        LoginCred Save(LoginCred loginCred);
        LoginCred UpdatePassword(LoginCred loginCred);
    }
}
