﻿using AuthenticationService.Model;
using MongoDB.Bson;
using MongoDB.Driver;

namespace AuthenticationService.Services
{
    public class CustomerService : ICustomerService
    {

        private readonly IMongoCollection<Customer> _cust;
        private readonly IMongoCollection<LoginCred> _loginCred;
        public CustomerService(AuthenticationService.Model.IMoviesDatabaseSettings moviesDatabaseSettings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(moviesDatabaseSettings.DatabaseName);
            _cust = database.GetCollection<Customer>("Customer_Collection");
            _cust.Indexes.CreateOne(
                new CreateIndexModel<Customer>(
                    Builders<Customer>.IndexKeys.Descending(m=>m.EmailId),
                new CreateIndexOptions { Unique= true}));
            _loginCred = database.GetCollection<LoginCred>("LoginCred_Collection");
        }
        public Customer Create(Customer customer)
        {
            _cust.InsertOne(customer);
            return customer;
        }

        public LoginCred Save(LoginCred loginCred)
        {
            _loginCred.InsertOne(loginCred);
            return loginCred;
        }

        public LoginCred UpdatePassword(LoginCred loginCred)
        {
            var filter = Builders<LoginCred>.Filter.Eq("_id", loginCred.LoginId);
            var update = Builders<LoginCred>.Update
                .Set("PasswordHash", loginCred.PasswordHash)
                .Set("PasswordSalt", loginCred.PasswordSalt);
            _loginCred.UpdateOne(filter,update);
            return loginCred;
        }


        public List<Customer> GetCustomers()
        {
            return _cust.Find(a => true).ToList();
        }

        public Customer GetById(string loginId)
        {
            return _cust.Find(a => a.LoginId == loginId).FirstOrDefault();
        }

        public LoginCred GetLoginCred(string loginId)
        {
            return _loginCred.Find(a => a.LoginId == loginId).FirstOrDefault();
        }


    }
}
