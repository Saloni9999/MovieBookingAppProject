﻿using AuthenticationService.Model;

namespace AuthenticationService.Security
{
    public interface IAuthenticationIdentity
    {
        void CreatePasswordHashSalt(string password, out byte[] passwordHash, out byte[] passwordSalt);
        bool AuthorizaUser(string password, byte[] passwordHash, byte[] passwordSalt);
        string CreateToken(string loginId, string password, string userRole);
    }
}
