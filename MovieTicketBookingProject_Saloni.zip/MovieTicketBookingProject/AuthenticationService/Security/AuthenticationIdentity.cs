﻿using AuthenticationService.Model;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection.Metadata.Ecma335;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace AuthenticationService.Security
{
    public class AuthenticationIdentity : IAuthenticationIdentity
    {
        public void CreatePasswordHashSalt(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            using(var hmac = new HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        public bool AuthorizaUser(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            using (var hmac = new HMACSHA512(passwordSalt))
            {
                var computeHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                var isAuthorize = computeHash.SequenceEqual(passwordHash);
                return isAuthorize;
            }
        }

        public string CreateToken(string loginId, string password, string userRole)
        {
            string token = string.Empty;

            List<Claim> claims = new List<Claim>
            {
                new Claim("UserName", loginId),
                new Claim("Password", password),
                new Claim(ClaimTypes.Role, userRole)
            };
            //var keyBytes = new byte[64];
            //using (var rng = new RNGCryptoServiceProvider())
            //{
            //    rng.GetBytes(keyBytes);
            //}
            //var key = new SymmetricSecurityKey(keyBytes);

            var key = new SymmetricSecurityKey(System.Text.Encoding.UTF8.GetBytes("Security_key_random_drh4s5hcar8jh"));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512);
            var jwt = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: creds
                ) ;
            token = new JwtSecurityTokenHandler().WriteToken(jwt);
            return token;
        }
        
    }
}
