﻿using Confluent.Kafka;

namespace AuthenticationService.KafkaServices
{
    public class KafkaConsumer : BackgroundService
    {
        private readonly ILogger<KafkaConsumer> _logger;
        private readonly ConsumerConfig _config;
        private readonly string _topic;

        public KafkaConsumer(ILogger<KafkaConsumer> logger)
        {
            _logger = logger;
            _config = new ConsumerConfig
            {
                BootstrapServers = "localhost:9092",
                GroupId = "test-consumer-group",
                AutoOffsetReset = AutoOffsetReset.Earliest
            };
            _topic = "movieTopic";
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using var consumer = new ConsumerBuilder<Ignore, string>(_config).Build();
            consumer.Subscribe(_topic);

            try
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    var consumerResult = consumer
                        .Consume(stoppingToken);
                    _logger.LogInformation("Consumermessage");
                }
            }
            catch (OperationCanceledException)
            {
                _logger.LogError("error");
            }
            finally { consumer.Close(); }
        }
    }
}
