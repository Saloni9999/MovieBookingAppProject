﻿using AuthenticationService.Model;
using AuthenticationService.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AuthenticationService.Services;

namespace AuthenticationService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IAuthenticationIdentity _authenticationIdentity;
        private readonly ICustomerService _customerService;
        private readonly ILogger<LoginController> _logger;

        public LoginController(IAuthenticationIdentity authenticationIdentity, ICustomerService customerService, ILogger<LoginController> logger)
        {
            _authenticationIdentity = authenticationIdentity;
            _customerService = customerService;
            _logger = logger;
        }


        [HttpPost("Register")]
        public ActionResult<Customer> Register(Customer customer)
        {
            _authenticationIdentity.CreatePasswordHashSalt(customer.Password, out byte[] passwordHash, out byte[] passwordSalt);
            LoginCred loginCred = new LoginCred();
            loginCred.LoginId = customer.LoginId;
            loginCred.EmailId = customer.EmailId;
            loginCred.UserRole = "User";
            loginCred.PasswordHash = passwordHash;
            loginCred.PasswordSalt = passwordSalt;
            try
            {
                _customerService.Create(customer);
                _logger.LogInformation("Registration Successful");
                _customerService.Save(loginCred);
                _logger.LogInformation("Registration Data Saved");
                return customer;
            }
            catch (Exception ex) 
            { 
                _logger.LogInformation($"Error: {ex.Message}");
                return BadRequest(ex.Message);
            }
            
        }


        [HttpPost("ResetPassword")]
        public ActionResult<LoginCred> ResetPassword(string loginId, string emailId, string password)
        {
            var user = _customerService.GetById(loginId);
            if (user == null)
            {
                _logger.LogInformation($"{loginId} is not registered.");
                return NotFound("Login Id does not exist");
            }
            if(user.EmailId != emailId)
            {
                _logger.LogInformation("Incorrect Email ID");
                return BadRequest("Incorrect EmailId");
            }
            _authenticationIdentity.CreatePasswordHashSalt(password, out byte[] passwordHash, out byte[] passwordSalt);
            LoginCred loginCred = new LoginCred();
            loginCred.LoginId = loginId;
            loginCred.EmailId = emailId;
            loginCred.UserRole = "User";
            loginCred.PasswordHash = passwordHash;
            loginCred.PasswordSalt = passwordSalt;
            _customerService.UpdatePassword(loginCred);
            _logger.LogInformation($"{loginCred.LoginId} Updated Password");
            return loginCred;
        }


        [HttpGet]
        public ActionResult<string> Login(string loginId, string password, string userRole= "User")
        {
            string token = string.Empty;
            var cust = _customerService.GetById(loginId);
            if (cust == null)
            {
                _logger.LogInformation("Invalid Login Id attemped");
                return NotFound("Login Id does not exist");
            }
            var loginCred = _customerService.GetLoginCred(loginId);
            if (loginCred == null || loginCred.UserRole != userRole)
            {
                _logger.LogInformation("Invalid Login Id attempted");
                return NotFound("Login Id does not exist");
            }
            var Authorized = _authenticationIdentity.AuthorizaUser(password ,loginCred.PasswordHash, loginCred.PasswordSalt);
            if(!Authorized)
            {
                _logger.LogInformation("Invalid Password attempted");
                return NotFound("Invalid Password");
            }
            else
                token = _authenticationIdentity.CreateToken(loginId, password, userRole);
            _logger.LogInformation("User logged in successfully");
            return token;
        }

    }
}
