﻿using AuthenticationService.Controllers;
using AuthenticationService.Security;
using Microsoft.Extensions.Logging;
using Moq;
using MovieTicket_Booking.Controllers;
using AuthenticationService.Model;
using AuthenticationService.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace MovieTicketBooking_Test.AuthenticateionService.ControllersTest
{
    [TestClass]
    public class LoginControllerTest
    {
        private Mock<IAuthenticationIdentity> mockAuthenticationIdentity;
        private Mock<ICustomerService> mockCustomerService;
        private Mock<ILogger<LoginController>> mockLogger;

        private LoginController controller;


        /// <summary>
        /// Test Initialize
        /// </summary>
        [TestInitialize]
        public void TestInitialize()
        {
            mockCustomerService = new Mock<ICustomerService>();
            mockAuthenticationIdentity = new Mock<IAuthenticationIdentity>();
            mockLogger= new Mock<ILogger<LoginController>>();
            controller = new LoginController(mockAuthenticationIdentity.Object, mockCustomerService.Object, mockLogger.Object);
        }


        /// <summary>
        /// Login Test Method
        /// </summary>
        [TestMethod]
        public void LoginTest()
        {
            //Arrange
            Customer customer= new Customer();
            LoginCred loginCred = new LoginCred
            {
                LoginId = "Test",
                EmailId= "Test@email.com",
                PasswordHash = new byte[] {},
                PasswordSalt= new byte[] {},
                UserRole = "User"
            };
            string token = "Just test Token";
            mockCustomerService.Setup(s => s.GetById("Test")).Returns(customer);
            mockCustomerService.Setup(s => s.GetLoginCred("Test")).Returns(loginCred);
            mockAuthenticationIdentity.Setup(s => s.AuthorizaUser("Test", new byte[] { }, new byte[] { })).Returns(true);
            mockAuthenticationIdentity.Setup(s => s.CreateToken("Test", "Test", "User")).Returns(token);

            //Act
            var token2 = controller.Login("Test", "Test");

            //Assert
            Assert.IsNotNull(token2);
            Assert.AreEqual(token2.Value, token);
        }

        /// <summary>
        /// Wrong Customer Test
        /// </summary>
        [TestMethod]
        public void LoginWrongCustomerTest()
        {
            //Arrange
            Customer customer = new Customer();
            string token = "Just test Token";
            mockCustomerService.Setup(s => s.GetById("Test"));
            
            //Act
            var result = controller.Login("Test", "Test");

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value, "Login Id does not exist");
        }


        /// <summary>
        /// Wrong Login Id Test
        /// </summary>
        [TestMethod]
        public void LoginWrongLoginIdTest()
        {
            //Arrange
            Customer customer = new Customer();
            string token = "Just test Token";
            mockCustomerService.Setup(s => s.GetById("Test")).Returns(customer);
            mockCustomerService.Setup(s => s.GetLoginCred("Test"));
            
            //Act
            var result = controller.Login("Test", "Test");

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value, "Login Id does not exist");
        }


        /// <summary>
        /// Wrong User Type Test
        /// </summary>
        [TestMethod]
        public void LoginWrongUserTypeTest()
        {
            //Arrange
            Customer customer = new Customer();
            LoginCred loginCred = new LoginCred
            {
                LoginId = "Test",
                EmailId = "Test@email.com",
                PasswordHash = new byte[] { },
                PasswordSalt = new byte[] { },
                UserRole = "User"
            };
            string token = "Just test Token";
            mockCustomerService.Setup(s => s.GetById("Test")).Returns(customer);
            mockCustomerService.Setup(s => s.GetLoginCred("Test")).Returns(loginCred);
            
            //Act
            var result = controller.Login("Test", "Test","Admin");

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value, "Login Id does not exist");
        }


        /// <summary>
        /// Wrong Password Test
        /// </summary>
        [TestMethod]
        public void LoginWrongPasswordTest()
        {
            //Arrange
            Customer customer = new Customer();
            LoginCred loginCred = new LoginCred
            {
                LoginId = "Test",
                EmailId = "Test@email.com",
                PasswordHash = new byte[] { },
                PasswordSalt = new byte[] { },
                UserRole = "User"
            };
            string token = "Just test Token";
            mockCustomerService.Setup(s => s.GetById("Test")).Returns(customer);
            mockCustomerService.Setup(s => s.GetLoginCred("Test")).Returns(loginCred);
            mockAuthenticationIdentity.Setup(s => s.AuthorizaUser("Test", new byte[] { }, new byte[] { })).Returns(false);
            
            //Act
            var result = controller.Login("Test", "Test");

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(((Microsoft.AspNetCore.Mvc.ObjectResult)result.Result).Value, "Invalid Password");
        }

    }
}
