﻿using Microsoft.Extensions.Logging;
using Moq;
using MovieTicket_Booking.Controllers;
using MovieTicket_Booking.KafkaServices;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ControllersTest
{
    [TestClass]
    public class TicketControllerTest
    {
        private Mock<ITicketService> mockTicketService;
        private Mock<IMoviesService> mockMoviesService;
        private Mock<ILogger<TicketController>> mockLogger;
        private Mock<IKafkaProducer> mockProducer;
        
        private TicketController controller;

        [TestInitialize]
        public void TestInitialize()
        {
            mockTicketService = new Mock<ITicketService>();
            mockMoviesService= new Mock<IMoviesService>();
            mockLogger = new Mock<ILogger<TicketController>>();
            mockProducer = new Mock<IKafkaProducer>(); 
            controller = new TicketController(mockTicketService.Object, mockMoviesService.Object, mockLogger.Object, mockProducer.Object);
        }

        [TestMethod]
        public void BookTicketTest()
        {
            //Arrange
            Ticket ticket = new Ticket
            {
                Id = "177",
                MovieName= "titanic",
                ThreaterName= "inox",
                NoOfTickets= 1,
                SeatNumber = "Test"
            };
            Movie movie = new Movie
            {
                Key = new MovieThreaterKey { MovieName = "avatar", ThreaterName = "inox" }, NoOfTicketsAlloted = 1,
            };
            mockMoviesService.Setup(s => s.GetByNameAndThreaterName("titanic", "inox")).Returns(movie);
            mockTicketService.Setup(s => s.Create(ticket)).Returns(ticket);

            //Act
            var ticket2 = controller.BookTicket(ticket);

            //Assert
            Assert.IsNotNull(ticket2);
            Assert.AreEqual(ticket2.Value, ticket);
            
        }

    }
}
