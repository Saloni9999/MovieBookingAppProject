﻿using Microsoft.Extensions.Logging;
using Moq;
using MovieTicket_Booking.Controllers;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
//using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ControllersTest
{
    [TestClass]
    public class MovieControllerTest
    {
        private Mock<IMoviesService> mockMoviesService;
        private Mock<ILogger<MovieController>> mockLogger;

        private MovieController controller;

        [TestInitialize]
        public void TestInitialize()
        {
            mockMoviesService= new Mock<IMoviesService>();
            mockLogger= new Mock<ILogger<MovieController>>();
            controller = new MovieController(mockMoviesService.Object, mockLogger.Object);
        }

        [TestMethod]
        public void GetAllMoviesTest()
        {
            //Arrange
            mockMoviesService.Setup(s => s.Get()).Returns(new List<Movie>
            {
                new Movie { Key=  new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb"}, NoOfTicketsAlloted = 10 }
            });

            //Act
            var movies = controller.GetAllMovies();

            //Assert
            Assert.IsNotNull(movies);
            Assert.AreEqual(movies.Value.Count, 1);
            Assert.AreEqual(movies.Value[0].Key.MovieName, "aa");
        }

        [TestMethod]
        public void GetMovieByNameTest()
        {
            //Arrange
            mockMoviesService.Setup(s => s.GetByName("aa")).Returns(new Movie
            {
                 Key=  new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb"}, NoOfTicketsAlloted = 10 
            });

            //Act
            var movie = controller.GetMovieByName("aa");

            //Assert
            Assert.IsNotNull(movie);
            Assert.AreEqual(movie.Value.Key.MovieName, "aa");
        }
    }
}
