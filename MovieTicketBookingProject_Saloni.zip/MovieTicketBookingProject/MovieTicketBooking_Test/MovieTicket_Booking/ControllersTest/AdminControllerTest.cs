﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.Extensions.Logging;
using Moq;
using MovieTicket_Booking.Controllers;
using MovieTicket_Booking.KafkaServices;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ControllersTest
{
    [TestClass]
    public class AdminControllerTest
    {
        private Mock<ITicketService> mockTicketService;
        private Mock<IMoviesService> mockMoviesService;
        private Mock<ILogger<AdminController>> mockLogger;
        private Mock<IKafkaProducer> mockProducer;

        private AdminController controller;

        [TestInitialize]
        public void TestInitialize()
        {
            mockTicketService = new Mock<ITicketService>();
            mockMoviesService= new Mock<IMoviesService>();
            mockLogger = new Mock<ILogger<AdminController>>();
            mockProducer = new Mock<IKafkaProducer>();
            controller = new AdminController(mockTicketService.Object, mockMoviesService.Object, mockLogger.Object, mockProducer.Object);
        }

        [TestMethod]
        public void BookedTicketsTest()
        {
            //Arrange
            List<Ticket> ticket = new List<Ticket>
            {
                new Ticket
                {
                Id = "1",
                MovieName = "Test",
                ThreaterName = "Test",
                NoOfTickets = 1,
                SeatNumber = "Test"
                }
            };
            mockTicketService.Setup(s => s.GetTicketsByMovieName("Test")).Returns(ticket);

            //Act
            var ticket2 = controller.BookedTickets("Test");

            //Assert
            Assert.IsNotNull(ticket2);
            Assert.AreEqual(ticket2.Value, ticket);

        }

        [TestMethod]
        public void GetTicketsRemainingTest()
        {
            //Arrange
            Movie movie = new Movie
            {
                Key = new MovieThreaterKey { MovieName = "Test", ThreaterName = "Test" },
                NoOfTicketsAlloted = 10
            };
            List<Ticket> tickets = new List<Ticket>
            {
                new Ticket
                {
                Id = "1",
                MovieName = "Test",
                ThreaterName = "Test",
                NoOfTickets = 1,
                SeatNumber = "Test"
                }
            };
            mockMoviesService.Setup(s => s.GetByNameAndThreaterName("Test", "Test")).Returns(movie);
            mockTicketService.Setup(s => s.GetTickets()).Returns(tickets);

            //Act
            var noOfTicketsRemaining = controller.GetTicketsRemaining("Test","Test");

            //Assert
            Assert.IsNotNull(noOfTicketsRemaining);
            Assert.AreEqual(noOfTicketsRemaining.Value, 9);

        }

        [TestMethod]
        public void DeleteMovieTest()
        {
            //Arrange
            var movie = new Movie();
            mockMoviesService.Setup(s => s.DeleteMovie(movie)).Returns(true);
            
            //Act
            var result = controller.DeleteMovie(movie);

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(result.Value, true);
            
        }


    }
}
