﻿using MongoDB.Driver;
using MongoDB.Driver.Core.Operations;
using Moq;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ServicesTest
{
    [TestClass]
    public class MovieServiceTest
    {
        private Mock<IMongoCollection<Movie>> _mockMovieCollection;

        private MoviesService service;

        [TestInitialize]
        public void Setup()
        {
            _mockMovieCollection = new Mock<IMongoCollection<Movie>>();
            Mock<IMongoDatabase> mockDatabase = new Mock<IMongoDatabase>();
            mockDatabase.Setup(d => d.GetCollection<Movie>("Movie_Collection", It.IsAny<MongoCollectionSettings>())).Returns(_mockMovieCollection.Object);
            var mockClient = new Mock<IMongoClient>();
            mockClient.Setup(c => c.GetDatabase("MovieDb", It.IsAny<MongoDatabaseSettings>())).Returns(mockDatabase.Object);
            var moviesDatabaseSetting = new MoviesDatabaseSettings { DatabaseName = "MovieDb", MoviesCollectionName = "Movie_Collection" };
            service = new MoviesService(moviesDatabaseSetting, mockClient.Object);
        }

        [TestMethod]
        public void CreateMovieTest()
        {
            //Arrange
            var movie = new Movie { Key = new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb" }, NoOfTicketsAlloted = 10 };
            
            //Act
            service.Create(movie);

            //Assert
            _mockMovieCollection.Verify(c => c.InsertOne(movie, It.IsAny<InsertOneOptions>(), It.IsAny<CancellationToken>()), Times.Once);

        }

        
        [TestMethod]
        public void GetTest()
        {
            //Arrange
            var movies = new List<Movie>
            {
                new Movie { Key = new MovieThreaterKey { MovieName = "test", ThreaterName = "bb" }, NoOfTicketsAlloted = 10 },
                new Movie { Key = new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb" }, NoOfTicketsAlloted = 10 }
            };
            var mockCursor = new Mock<IAsyncCursor<Movie>>();           
            _mockMovieCollection.Setup(x => x.FindSync(
                It.IsAny<FilterDefinition<Movie>>(),
                //Builders<Movie>.Filter.Empty,
                It.IsAny<FindOptions<Movie>>(), default)).Returns(mockCursor.Object);
            mockCursor.SetupSequence(_ => _.MoveNext(default)).Returns(true).Returns(false);
            mockCursor.SetupGet(_ => _.Current).Returns(movies);


            //_mockMovieCollection.Setup(c => c.Find(It.IsAny<System.Linq.Expressions.Expression<System.Func<Movie, bool>>>(), It.IsAny<FindOptions>()))
            //   .Returns(() => new EnumerableQuery<Movie>(movies));
            //_mockMovieCollection.SetupGet(c => c.Find(It.IsAny<System.Linq.Expressions.Expression<System.Func<Movie, bool>>>(), It.IsAny<FindOptions>()))
            //    .Returns((IFindFluent<Movie, Movie>)movies);

            //var findFlunet = new Mock<IFindFluent<Movie, Movie>>();
            //findFlunet.Setup(_ => _.ToCursor(It.IsAny<CancellationToken>())).Returns(mockCursor.Object);
            //mockCursor.Setup(_ => _.Current).Returns(movies);
            //var findFlunet = new Mock<IFindFluent<Movie, Movie>>();
            //findFlunet.Setup(_ => _.ToCursor(It.IsAny<CancellationToken>())).Returns(mockCursor.Object);
            //_mockMovieCollection.Setup(x => x.Find(It.IsAny<FilterDefinition<Movie>>(), default)).Returns(findFlunet.Object);

            //Act
            var moviesResult = service.Get();

            //Assert
            Assert.IsNotNull(moviesResult);
            Assert.AreEqual(moviesResult.Count, 2);
            
        }


        [TestMethod]
        public void GetMovieByNameTest()
        {
            //Arrange
            var movies = new List<Movie>
            {
                new Movie { Key = new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb" }, NoOfTicketsAlloted = 10 }
            };
            var mockCursor = new Mock<IAsyncCursor<Movie>>();
            _mockMovieCollection.Setup(x => x.FindSync(
                It.IsAny<FilterDefinition<Movie>>(),
                It.IsAny<FindOptions<Movie>>(), default)).Returns(mockCursor.Object);
            mockCursor.SetupSequence(_ => _.MoveNext(default)).Returns(true).Returns(false);
            mockCursor.SetupGet(_ => _.Current).Returns(movies);

            //Act
            var moviesResult = service.GetByName("aa");

            //Assert
            Assert.IsNotNull(moviesResult);
            Assert.AreEqual(moviesResult.NoOfTicketsAlloted, 10);
        }


        [TestMethod]
        public void DeleteMovieTest()
        {
            //Arrange
            var movie = new Movie { Key = new MovieThreaterKey { MovieName = "aa", ThreaterName = "bb" }, NoOfTicketsAlloted = 10 };
            var deleteResult = new DeleteResult.Acknowledged(1);
            _mockMovieCollection.Setup(s => s.DeleteMany(It.IsAny<FilterDefinition<Movie>>(), default)).Returns(deleteResult);


            //Act
            var result = service.DeleteMovie(movie);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result);

        }
    }
}
