﻿using MongoDB.Driver;
using Moq;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ServicesTest
{
    [TestClass]
    public class TicketServiceTest
    {
        private Mock<IMongoCollection<Ticket>> _mockTicketCollection;

        private TicketService service;

        [TestInitialize]
        public void Setup()
        {
            _mockTicketCollection = new Mock<IMongoCollection<Ticket>>();
            Mock<IMongoDatabase> mockDatabase = new Mock<IMongoDatabase>();
            mockDatabase.Setup(d => d.GetCollection<Ticket>("Ticket_Collection", It.IsAny<MongoCollectionSettings>())).Returns(_mockTicketCollection.Object);
            var mockClient = new Mock<IMongoClient>();
            mockClient.Setup(c => c.GetDatabase("MovieDb", It.IsAny<MongoDatabaseSettings>())).Returns(mockDatabase.Object);
            var moviesDatabaseSetting = new MoviesDatabaseSettings { DatabaseName = "MovieDb", MoviesCollectionName = "Movie_Collection" };
            service = new TicketService(moviesDatabaseSetting, mockClient.Object);
        }

        [TestMethod]
        public void CreateTicketTest()
        {
            //Arrange
            var ticket = new Ticket();  

            //Act
            service.Create(ticket);

            //Assert
            _mockTicketCollection.Verify(c => c.InsertOne(ticket, It.IsAny<InsertOneOptions>(), It.IsAny<CancellationToken>()), Times.Once);

        }

        [TestMethod]
        public void GetTicketsTest()
        {
            //Arrange
            var tickets = new List<Ticket>
            {
                new Ticket { Id = "1", }
            };
            var mockCursor = new Mock<IAsyncCursor<Ticket>>();
            _mockTicketCollection.Setup(x => x.FindSync(
                It.IsAny<FilterDefinition<Ticket>>(),
                It.IsAny<FindOptions<Ticket>>(), default)).Returns(mockCursor.Object);
            mockCursor.SetupSequence(_ => _.MoveNext(default)).Returns(true).Returns(false);
            mockCursor.SetupGet(_ => _.Current).Returns(tickets);

            //Act
            var moviesResult = service.GetTickets();

            //Assert
            Assert.IsNotNull(moviesResult);
            Assert.AreEqual(moviesResult.Count, 1);
        }


    }
}
