﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using MongoDB.Driver;
using Moq;
using MovieTicket_Booking.Models;
using MovieTicket_Booking.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MovieTicketBooking_Test.MovieTicket_Booking.ServicesTest
{
    [TestClass]
    public class CustomerServiceTest
    {
        private Mock<IMongoCollection<Customer>> _mockCustomerCollection;

        private CustomerService service;

        [TestInitialize]
        public void Setup()
        {
            _mockCustomerCollection = new Mock<IMongoCollection<Customer>>();
            var customer = new Customer();
            //var crt = new CreateIndexModel<Customer>();
            //_mockCustomerCollection.Object.Indexes.CreateOne(new CreateIndexModel<Customer>() customer, new CreateOneIndexOptions(), new CancellationToken());
            _mockCustomerCollection.Setup(c => c.Indexes.CreateOne(It.IsAny<CreateIndexModel<Customer>>(), It.IsAny<CreateOneIndexOptions>(), It.IsAny<CancellationToken>()));
            Mock<IMongoDatabase> mockDatabase = new Mock<IMongoDatabase>();
            mockDatabase.Setup(d => d.GetCollection<Customer>("Customer_Collection", It.IsAny<MongoCollectionSettings>())).Returns(_mockCustomerCollection.Object);           
            var mockClient = new Mock<IMongoClient>();
            mockClient.Setup(c => c.GetDatabase("MovieDb", It.IsAny<MongoDatabaseSettings>())).Returns(mockDatabase.Object);
            var moviesDatabaseSetting = new MoviesDatabaseSettings { DatabaseName = "MovieDb", MoviesCollectionName = "Customer_Collection" };
            service = new CustomerService(moviesDatabaseSetting, mockClient.Object);
        }

        [TestMethod]
        public void CreateCustomerTest()
        {
            //Arrange
            var cust = new Customer();

            //Act
            service.Create(cust);

            //Assert
           _mockCustomerCollection.Verify(c => c.InsertOne(cust, It.IsAny<InsertOneOptions>(), It.IsAny<CancellationToken>()), Times.Once);

        }

        [TestMethod]
        public void GetCustomersTest()
        {
            //Arrange
            var customers = new List<Customer>
            {
                new Customer()
            };            
            var mockCursor = new Mock<IAsyncCursor<Customer>>();
            _mockCustomerCollection.Setup(x => x.FindSync(
                It.IsAny<FilterDefinition<Customer>>(),
                It.IsAny<FindOptions<Customer>>(), default)).Returns(mockCursor.Object);
            mockCursor.SetupSequence(_ => _.MoveNext(default)).Returns(true).Returns(false);
            mockCursor.SetupGet(_ => _.Current).Returns(customers);

            //Act
            var customerResult = service.GetCustomers();

            //Assert
            Assert.IsNotNull(customerResult);
            Assert.AreEqual(customerResult.Count, 1);
        }


    }
}
